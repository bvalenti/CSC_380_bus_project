/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.csc380.API;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import javax.net.ssl.HttpsURLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.text.ParseException;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import java.time.LocalTime;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import static org.mockito.Mockito.*;

/**
 *
 * @author bill
 */
public class UtilityTest extends TestCase {
    
    //test encodeHashMap
    public void testEncodeHashMap () throws FileNotFoundException, IOException, ParseException, org.json.simple.parser.ParseException {
        FileOutputStream fo = new FileOutputStream("testEncoding.txt");
        PrintWriter pw = new PrintWriter(fo);
        Utility.parseTrips("trips.txt");
        Utility.parseStops("stops.txt");
        Utility.parseStopTimes("stop_times.txt");
        Utility.jsonParser("vehicle-monitoring.json");
        Utility.parseShapes("shapes.txt");
        Utility.assignTrips();
        Utility.encodeHashMap(pw);
        File f = new File("testEncoding.txt");
        Scanner fs = new Scanner(f);
        assertTrue(fs.hasNext());
    }
    
    //test assignTrips
    public void testAssignTrips() throws FileNotFoundException, IOException, 
            org.json.simple.parser.ParseException, ParseException {
        Utility.parseTrips("trips.txt");
        Utility.parseStops("stops.txt");
        Utility.jsonParser("vehicle-monitoring.json");
        Utility.parseShapes("shapes.txt");
        Utility.assignTrips();
        assertNotNull(Utility.busses.values().iterator().next().route_shape);
    }
    
    //test parseTrips
    public void testParseTrips() {
        try {
            Utility.parseTrips("trips.txt");
            assertNotNull(Utility.trips);
        } catch (FileNotFoundException ex) {
            assertTrue(false);
        }
    }
    
    //test parseStops
    public void testParseStops(){
        try {
            Utility.parseStops("stops.txt");
            assertNotNull(Utility.stops);
        } catch (FileNotFoundException ex) {
            assertTrue(false);
        }
    }
    
    //test parseStopTimes
    public void testParseStopTimes() throws FileNotFoundException{
        Utility.parseTrips("trips.txt");
        try {
            Utility.parseStopTimes("stop_times.txt");
            assertNotNull(Utility.trips.values().iterator().next().route);
        } catch (FileNotFoundException ex) {
            assertTrue(false);
        }
    }
    
    //test parseShapes
    public void testParseShapes () {
        try {
            Utility.parseShapes("shapes.txt");
            assertNotNull(Utility.shapes.values().iterator().next());
        } catch (FileNotFoundException ex) {
            assertTrue(false);
        }
    }
    
    //test openMTAApiConnection
    public void testOpenMTAApiConnection() throws InterruptedException, IOException{
        
            HttpURLConnection conn = Utility.openMTAApiConnection();
            
            assertNotNull(conn);
        
    }
    
    //test getFile
    public void testGetFile(){
        try {
            HttpURLConnection conn = mock(HttpURLConnection.class);
            File f = new File("testfile2.txt");
            FileInputStream finps = new FileInputStream(f);
            when(conn.getResponseCode()).thenReturn(200);
            when(conn.getInputStream()).thenReturn(finps);
            Utility.getFile(conn, 
                    "/home/bill/SchoolWork/csc380/CSC_380_bus_project", 
                    "testfile.txt", false);
            assertTrue(true);
        } catch (IOException ex) {
            assertTrue(false);
        }
    }
    
    // test startup tasks
//    public void testStartupTasks() throws InterruptedException, IOException{
//        Utility.startupTasks();
//        int first = Utility.updateModelExecuteCount;
//        Thread.sleep(72000);
//        int last = Utility.updateModelExecuteCount;
//        Utility.stopApiPoller();
//        assertTrue(first != last);
//    }
}
