/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.csc380.API;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

/**
 *
 * Responsible for responding to requests from client for:
 *      HashMap<String, Bus>
 *      
 * Recieving from client:
 *      Usage Statistics
 * 
 * 
 * @author bill
 */
public class MyServlet extends HttpServlet {
    
    //no login check or usage stats yet
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        if (request.getParameter("RequestType").equalsIgnoreCase(
                "getBusses")){
            Utility.encodeHashMap(out);
        }
    }
    
}
